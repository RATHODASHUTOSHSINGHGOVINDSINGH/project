const AddTodo = () => {
   // Access the todo input element
   let Todo = document.querySelector('#todo');
   let todoText = Todo.value.trim();
   // Check if todoText is not empty
   if (todoText !== '') { 
       // Create a new todo list item
       let newTodo = document.createElement('li');
       newTodo.textContent = todoText;
       let TodoList = document.querySelector('#todoList');
       TodoList.appendChild(newTodo);
       // Clear the input field after adding the todo
       Todo.value = '';
   } else {
       alert("Please Enter a task");
   }
};

const DeleteTodo = () => {
   let TodoList = document.querySelector('#todoList');
   // Check if there are any todo items to delete
   if (TodoList.children.length > 0) {
       TodoList.removeChild(TodoList.lastChild);
   } else {
       alert("No task to be deleted");
   }
};
